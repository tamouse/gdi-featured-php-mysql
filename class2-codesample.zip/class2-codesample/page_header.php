<!DOCTYPE html>
<html>
    <head>
        <meta charset="utf-8">
        <meta name="viewport" content="width=device-width,
                                       initial-scale=1">
        <title><?php echo $page_title ?></title>
    </head>
    <body>
        <h1><?php echo $page_title ?></h1>

        <!-- page content starts here -->
