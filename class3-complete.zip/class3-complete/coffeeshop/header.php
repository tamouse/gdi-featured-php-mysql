<?php
// Report all PHP errors
error_reporting(-1);
?>

<!doctype html>
<html>
<head>
	<title>Wake Up!</title>
	<link rel="stylesheet" type="text/css" href="style.css">
</head>
<body>
	<div class="container">
		<div class="header">
			<h1>Wake Up!</h1>
			<h2>A Site About Coffee</h2>
		</div><!-- .header -->
		<div class="main">
            <div class="content">