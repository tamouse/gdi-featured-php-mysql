<?php
// This is a template file you can use to create new php files.


// require once functions and setup, e.g.:
// require_once 'utilities.inc.php';
// require_once 'db.inc.php';



// declare any functions


// gather and prepare data


// either send a relocation header:
// header('Location: view-products.php');
// and delete the rest of the code


// or output the page
include_once 'header.php';
?>
    <p>Your content here.</p>
<?php
include_once 'sidebar.php';
include_once 'footer.php';
?>