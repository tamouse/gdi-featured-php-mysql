<div class="footer">
    <span>An example site by Amy Hendrix &amp; Sylvia Richardson</span>
    </div><!-- .footer -->
</div><!-- .container -->
</body>
</html>